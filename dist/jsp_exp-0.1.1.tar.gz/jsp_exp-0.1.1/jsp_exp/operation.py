import dataclasses
from typing import Any, List, Optional


@dataclasses.dataclass
class Operation(object):
    name: str = 'Operation'
    r: Optional[int] = None
    p: Optional[int] = None
    q: Optional[int] = None
    processed_by: Any

    def __str__(self) -> str:
        return self.name

    @property
    def r(self) -> int:
        return self.r

    @r.setter
    def r(self, new_val: int) -> None:
        err_msg = 'Your adjustment of r is invalid because it makes situation worse.'
        assert self.r <= new_val, err_msg
        self.r = new_val

    @property
    def q(self) -> int:
        return self.q

    @q.setter
    def q(self, new_val: int) -> None:
        err_msg = 'Your adjustment of q is invalid because it makes situation worse.'
        assert self.q <= new_val, err_msg
        self.q = new_val
